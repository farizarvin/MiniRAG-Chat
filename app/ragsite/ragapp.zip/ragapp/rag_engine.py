import os, glob, json, numpy as np, torch, re
from typing import List, Dict, Tuple
from sentence_transformers import SentenceTransformer
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

# --- FAISS opsional ---
USE_FAISS = True
try:
    import faiss
except Exception:
    USE_FAISS = False
    faiss = None

# --- Path dasar ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
INDEX_PATH = os.path.join(BASE_DIR, "vector.index")
META_PATH  = os.path.join(BASE_DIR, "meta.json")
os.makedirs(DATA_DIR, exist_ok=True)

# --- Model embedding dan generatif ---
EMB_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
GEN_MODEL_NAME = "google/flan-t5-base"

torch.set_num_threads(max(1, torch.get_num_threads()))
os.environ['TOKENIZERS_PARALLELISM'] = 'false'

# =========================================================
# Fungsi bantu
# =========================================================
def read_txt(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def split_into_chunks(text: str, chunk_size: int = 600, overlap: int = 100) -> List[str]:
    """Memecah isi teks panjang menjadi potongan beririsan."""
    text = " ".join(text.split())
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunks.append(text[start:end])
        if end == len(text):
            break
        start = end - overlap
    return chunks

# =========================================================
# Load korpus dan metadata
# =========================================================
def load_corpus(data_dir: str) -> Tuple[List[str], List[Dict]]:
    files = sorted(glob.glob(os.path.join(data_dir, "*.txt")))
    corpus, meta = [], []

    for fpath in files:
        raw = read_txt(fpath)
        # default metadata
        info = {
            "title": "Unknown",
            "penulis": "Unknown",
            "genre": "Unknown",
            "penerbit": "Unknown",
            "tahun": "Unknown",
            "katakunci": "Unknown",
        }

        penerbit_line = ""
        for line in raw.splitlines():
            line_lower = line.lower()
            if line_lower.startswith("judul:"):
                info["title"] = line.split(":", 1)[1].strip()
            elif line_lower.startswith("penulis:"):
                info["penulis"] = line.split(":", 1)[1].strip()
            elif line_lower.startswith("genre:"):
                info["genre"] = line.split(":", 1)[1].strip()
            elif line_lower.startswith("penerbit:"):
                penerbit_line = line.split(":", 1)[1].strip()
            elif line_lower.startswith("kata kunci:"):
                info["katakunci"] = line.split(":", 1)[1].strip()
                # pecah penerbit & tahun jika formatnya ada koma
                if ',' in penerbit_line:
                    penerbit, tahun = [x.strip() for x in penerbit_line.rsplit(',', 1)]
                    info["penerbit"], info["tahun"] = penerbit, tahun
                else:
                    info["penerbit"] = penerbit_line

        # isi buku
        content_start = raw.lower().find("isi:")
        if content_start != -1:
            content = raw[content_start + len("isi:"):].strip()
        else:
            content = raw.strip()

        if info["katakunci"]:
            content = f"Kata kunci: {info['katakunci']}\n\n{content}"

        chunks = split_into_chunks(content)
        for i, ch in enumerate(chunks):
            corpus.append(ch)
            meta.append({
                **info,
                "source": os.path.basename(fpath),
                "chunk_id": i
            })
    return corpus, meta

# =========================================================
# Retriever (FAISS + embeddings)
# =========================================================
class Retriever:
    def __init__(self, emb_model_name: str):
        self.embedder = SentenceTransformer(emb_model_name)
        self.embeddings = None
        self.meta = []
        self.index = None

    def build(self, corpus: List[str], meta: List[Dict]):
        self.meta = meta
        embs = self.embedder.encode(corpus, show_progress_bar=True, convert_to_numpy=True, normalize_embeddings=True)
        self.embeddings = embs.astype("float32")
        if USE_FAISS:
            dim = self.embeddings.shape[1]
            index = faiss.IndexFlatIP(dim)
            index.add(self.embeddings)
            self.index = index
            faiss.write_index(index, INDEX_PATH)
            with open(META_PATH, "w", encoding="utf-8") as f:
                json.dump(meta, f, ensure_ascii=False, indent=2)
        else:
            self.index = None

    def maybe_load(self):
        if USE_FAISS and os.path.exists(INDEX_PATH) and os.path.exists(META_PATH):
            self.index = faiss.read_index(INDEX_PATH)
            with open(META_PATH, "r", encoding="utf-8") as f:
                self.meta = json.load(f)
            return True
        return False

    def search(self, query: str, k: int = 4):
        q = self.embedder.encode([query], convert_to_numpy=True, normalize_embeddings=True).astype("float32")
        if USE_FAISS and self.index:
            D, I = self.index.search(q, k)
            return I[0].tolist(), D[0].tolist()
        else:
            sims = (self.embeddings @ q[0])
            idxs = np.argsort(sims)[::-1][:k]
            return idxs.tolist(), sims[idxs].tolist()

# =========================================================
# Generator (T5)
# =========================================================
class Generator:
    def __init__(self, model_name: str):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(model_name).to(self.device)

    def generate(self, question: str, contexts: List[str], selected_meta: List[Dict], max_new_tokens: int = 256):
        q_lower = question.lower()

        # --- 1️⃣ Tangani pertanyaan tentang referensi/buku
        if any(kw in q_lower for kw in ["buku", "referensi", "literatur", "judul", "penulis"]):
            if selected_meta:
                m = selected_meta[0]
                return (
                    f"AI bisa dipelajari pada buku **{m.get('title', 'Unknown')}** "
                    f"oleh penulis {m.get('penulis', 'Unknown')}."
                )
            else:
                return "Belum ada data buku yang relevan untuk pertanyaan tersebut."

        # --- 2️⃣ Jika topik tidak ditemukan dalam konteks (cek berdasarkan Kata Kunci di meta)
        all_keywords = []
        for m in selected_meta:
            if m.get("katakunci"):
                kws = [kw.strip().lower() for kw in re.split(r"[;,]", m["katakunci"]) if kw.strip()]
                all_keywords.extend(kws)

        all_keywords = list(set(all_keywords))  # hilangkan duplikat

        # Jika pertanyaan tidak mengandung salah satu kata kunci dari metadata
        if not any(kw in q_lower for kw in all_keywords):
            if any(x in q_lower for x in ["sql", "basis data", "database"]):
                return "Pengetahuan mengenai SQL belum lengkap berdasarkan data yang ada."
            return "Maaf, informasi mengenai topik tersebut belum tersedia."

        # --- 3️⃣ Normal RAG generation
        prompt = build_prompt(question, contexts)
        inputs = self.tokenizer(prompt, return_tensors="pt", truncation=True, max_length=1024).to(self.device)
        outputs = self.model.generate(**inputs, max_new_tokens=max_new_tokens)
        return self.tokenizer.decode(outputs[0], skip_special_tokens=True)

# =========================================================
# Prompt builder
# =========================================================
def build_prompt(question: str, contexts: List[str]) -> str:
    ctx_block = "\n\n".join([f"[Konteks {i+1}]\n{c}" for i, c in enumerate(contexts)])
    prompt = (
        "Anda adalah asisten perpustakaan universitas. "
        "Jawablah pertanyaan dengan ringkas, berdasarkan isi buku berikut.\n\n"
        f"{ctx_block}\n\nPertanyaan: {question}\n\nJawaban:"
    )
    return prompt

def format_citations(selected_meta: List[Dict]) -> str:
    return "\n".join([f"- {m['title']} ({m['source']}, chunk {m['chunk_id']})" for m in selected_meta])

# =========================================================
# Inisialisasi
# =========================================================
retriever = Retriever(EMB_MODEL_NAME)
generator = Generator(GEN_MODEL_NAME)

corpus, meta = load_corpus(DATA_DIR)
retriever.build(corpus, meta)

# =========================================================
# Fungsi utama untuk tanya
# =========================================================
def handle_query(question: str, top_k: int = 4):
    idxs, _ = retriever.search(question, k=top_k)
    contexts = [corpus[i] for i in idxs]
    metas = [meta[i] for i in idxs]
    answer = generator.generate(question, contexts=contexts, selected_meta=metas)
    citations = format_citations(metas)
    return answer, citations

# =========================================================
# 🧠 Contoh Pemanggilan (jalankan bagian ini)
# =========================================================
if __name__ == "__main__":
    question = "Apa itu AI dan siapa penulis buku tentangnya?"
    answer, citations = handle_query(question)
    print("🧩 Jawaban:", answer)
    print("\n📚 Sumber:")
    print(citations)
