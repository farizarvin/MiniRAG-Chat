from django.shortcuts import render
from .rag_engine import handle_query  # cukup ini

def ask(request):
    answer = citations = question = ""
    if request.method == "POST":
        question = request.POST.get("question", "").strip()
        if question:
            # Jalankan pipeline RAG
            answer, citations = handle_query(question)
    return render(request, "index.html", {
        "answer": answer,
        "citations": citations,
        "question": question
    })

